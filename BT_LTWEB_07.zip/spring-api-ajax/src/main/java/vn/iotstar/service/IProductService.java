package vn.iotstar.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import vn.iotstar.entity.Product;

public interface IProductService {
	<S extends Product> S save(S entity);

	void delete(Product entity);

	Optional<Product> findById(Long id);

	Optional<Product> findByProductName(String name);

	List<Product> findAll();

	Page<Product> findAll(Pageable pageable);

	long count();

	List<Product> findByProductNameContaining(String name);

	Page<Product> findByProductNameContaining(String name, Pageable pageable);

	boolean existsByCategoryId(Long categoryId);
}
