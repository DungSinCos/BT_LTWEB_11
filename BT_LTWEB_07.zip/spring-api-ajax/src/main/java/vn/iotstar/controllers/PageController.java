package vn.iotstar.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/** Trả về các trang JSP dùng Ajax */
@Controller
public class PageController {

	@GetMapping("/")
	public String home() {
		return "redirect:/admin/ajax/category";
	}

	@GetMapping("/admin/ajax/category")
	public String category() {
		return "admin/ajax/category";
	}

	@GetMapping("/admin/ajax/product")
	public String product() {
		return "admin/ajax/product";
	}
}
