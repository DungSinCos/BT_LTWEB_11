package vn.iotstar.controllers.api;

import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import vn.iotstar.entity.Category;
import vn.iotstar.model.Response;
import vn.iotstar.service.ICategoryService;
import vn.iotstar.service.IProductService;
import vn.iotstar.service.IStorageService;

@RestController
@RequestMapping(path = "/api/category")
public class CategoryAPIController {

	@Autowired
	private ICategoryService categoryService;

	@Autowired
	private IProductService productService;

	@Autowired
	private IStorageService storageService;

	@GetMapping
	public ResponseEntity<?> getAllCategory() {
		return new ResponseEntity<Response>(new Response(true, "Thành công", categoryService.findAll()), HttpStatus.OK);
	}

	@PostMapping(path = "/getCategory")
	public ResponseEntity<?> getCategory(@RequestParam("id") Long id) {
		Optional<Category> category = categoryService.findById(id);
		if (category.isPresent()) {
			return new ResponseEntity<Response>(new Response(true, "Thành công", category.get()), HttpStatus.OK);
		}
		return new ResponseEntity<Response>(new Response(false, "Thất bại", null), HttpStatus.NOT_FOUND);
	}

	@PostMapping(path = "/addCategory")
	public ResponseEntity<?> addCategory(@RequestParam("categoryName") String categoryName,
			@RequestParam(value = "icon", required = false) MultipartFile icon) {
		Optional<Category> optCategory = categoryService.findByCategoryName(categoryName);
		if (optCategory.isPresent()) {
			return new ResponseEntity<Response>(new Response(false, "Category đã tồn tại trong hệ thống", null),
					HttpStatus.BAD_REQUEST);
		}
		Category category = new Category();
		// kiểm tra tồn tại file, lưu file
		if (icon != null && !icon.isEmpty()) {
			String fileName = storageService.getSorageFilename(icon, UUID.randomUUID().toString());
			storageService.store(icon, fileName);
			category.setIcon(fileName);
		}
		category.setCategoryName(categoryName);
		categoryService.save(category);
		return new ResponseEntity<Response>(new Response(true, "Thêm thành công", category), HttpStatus.OK);
	}

	@PutMapping(path = "/updateCategory")
	public ResponseEntity<?> updateCategory(@RequestParam("categoryId") Long categoryId,
			@RequestParam("categoryName") String categoryName,
			@RequestParam(value = "icon", required = false) MultipartFile icon) {
		Optional<Category> optCategory = categoryService.findById(categoryId);
		if (optCategory.isEmpty()) {
			return new ResponseEntity<Response>(new Response(false, "Không tìm thấy Category", null),
					HttpStatus.BAD_REQUEST);
		}
		Category category = optCategory.get();
		if (icon != null && !icon.isEmpty()) {
			String fileName = storageService.getSorageFilename(icon, UUID.randomUUID().toString());
			storageService.store(icon, fileName);
			category.setIcon(fileName);
		}
		category.setCategoryName(categoryName);
		categoryService.save(category);
		return new ResponseEntity<Response>(new Response(true, "Cập nhật thành công", category), HttpStatus.OK);
	}

	@DeleteMapping(path = "/deleteCategory")
	public ResponseEntity<?> deleteCategory(@RequestParam("categoryId") Long categoryId) {
		Optional<Category> optCategory = categoryService.findById(categoryId);
		if (optCategory.isEmpty()) {
			return new ResponseEntity<Response>(new Response(false, "Không tìm thấy Category", null),
					HttpStatus.BAD_REQUEST);
		}
		if (productService.existsByCategoryId(categoryId)) {
			return new ResponseEntity<Response>(
					new Response(false, "Category đang có sản phẩm, hãy xóa/chuyển sản phẩm trước", null),
					HttpStatus.BAD_REQUEST);
		}
		categoryService.delete(optCategory.get());
		return new ResponseEntity<Response>(new Response(true, "Xóa thành công", optCategory.get()), HttpStatus.OK);
	}
}
