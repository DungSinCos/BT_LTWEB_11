package vn.iotstar.controllers.api;

import java.util.Date;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import vn.iotstar.entity.Category;
import vn.iotstar.entity.Product;
import vn.iotstar.model.Response;
import vn.iotstar.service.ICategoryService;
import vn.iotstar.service.IProductService;
import vn.iotstar.service.IStorageService;

@RestController
@RequestMapping(path = "/api/product")
public class ProductApiController {

	@Autowired
	IProductService productService;

	@Autowired
	ICategoryService categoryService;

	@Autowired
	IStorageService storageService;

	@GetMapping
	public ResponseEntity<?> getAllProduct() {
		return new ResponseEntity<Response>(new Response(true, "Thành công", productService.findAll()), HttpStatus.OK);
	}

	@PostMapping(path = "/getProduct")
	public ResponseEntity<?> getProduct(@RequestParam("id") Long id) {
		Optional<Product> p = productService.findById(id);
		if (p.isPresent()) {
			return new ResponseEntity<Response>(new Response(true, "Thành công", p.get()), HttpStatus.OK);
		}
		return new ResponseEntity<Response>(new Response(false, "Không tìm thấy sản phẩm", null), HttpStatus.NOT_FOUND);
	}

	@PostMapping(path = "/addProduct")
	public ResponseEntity<?> addProduct(@RequestParam("productName") String productName,
			@RequestParam(value = "imageFile", required = false) MultipartFile imageFile,
			@RequestParam("unitPrice") Double unitPrice, @RequestParam("discount") Double discount,
			@RequestParam("description") String description, @RequestParam("categoryId") Long categoryId,
			@RequestParam("quantity") Integer quantity, @RequestParam("status") Short status) {

		if (productService.findByProductName(productName).isPresent()) {
			return new ResponseEntity<Response>(new Response(false, "Sản phẩm này đã tồn tại trong hệ thống", null),
					HttpStatus.BAD_REQUEST);
		}
		Optional<Category> cate = categoryService.findById(categoryId);
		if (cate.isEmpty()) {
			return new ResponseEntity<Response>(new Response(false, "Không tìm thấy Category", null),
					HttpStatus.BAD_REQUEST);
		}

		Product product = new Product();
		product.setProductName(productName);
		product.setUnitPrice(unitPrice);
		product.setDiscount(discount);
		product.setDescription(description);
		product.setQuantity(quantity);
		product.setStatus(status);
		product.setCategory(cate.get());
		product.setCreateDate(new Date());

		if (imageFile != null && !imageFile.isEmpty()) {
			String fileName = storageService.getSorageFilename(imageFile, UUID.randomUUID().toString());
			storageService.store(imageFile, fileName);
			product.setImages(fileName);
		}
		productService.save(product);
		return new ResponseEntity<Response>(new Response(true, "Thêm thành công", product), HttpStatus.OK);
	}

	@PutMapping(path = "/updateProduct")
	public ResponseEntity<?> updateProduct(@RequestParam("productId") Long productId,
			@RequestParam("productName") String productName,
			@RequestParam(value = "imageFile", required = false) MultipartFile imageFile,
			@RequestParam("unitPrice") Double unitPrice, @RequestParam("discount") Double discount,
			@RequestParam("description") String description, @RequestParam("categoryId") Long categoryId,
			@RequestParam("quantity") Integer quantity, @RequestParam("status") Short status) {

		Optional<Product> opt = productService.findById(productId);
		if (opt.isEmpty()) {
			return new ResponseEntity<Response>(new Response(false, "Không tìm thấy Product", null),
					HttpStatus.BAD_REQUEST);
		}
		Optional<Category> cate = categoryService.findById(categoryId);
		if (cate.isEmpty()) {
			return new ResponseEntity<Response>(new Response(false, "Không tìm thấy Category", null),
					HttpStatus.BAD_REQUEST);
		}

		Product product = opt.get();
		product.setProductName(productName);
		product.setUnitPrice(unitPrice);
		product.setDiscount(discount);
		product.setDescription(description);
		product.setQuantity(quantity);
		product.setStatus(status);
		product.setCategory(cate.get());

		if (imageFile != null && !imageFile.isEmpty()) {
			String fileName = storageService.getSorageFilename(imageFile, UUID.randomUUID().toString());
			storageService.store(imageFile, fileName);
			product.setImages(fileName);
		}
		productService.save(product);
		return new ResponseEntity<Response>(new Response(true, "Cập nhật thành công", product), HttpStatus.OK);
	}

	@DeleteMapping(path = "/deleteProduct")
	public ResponseEntity<?> deleteProduct(@RequestParam("productId") Long productId) {
		Optional<Product> opt = productService.findById(productId);
		if (opt.isEmpty()) {
			return new ResponseEntity<Response>(new Response(false, "Không tìm thấy Product", null),
					HttpStatus.BAD_REQUEST);
		}
		productService.delete(opt.get());
		return new ResponseEntity<Response>(new Response(true, "Xóa thành công", opt.get()), HttpStatus.OK);
	}
}
