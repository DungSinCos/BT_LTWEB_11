package vn.iotstar.config;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SiteMeshConfig {
	@Bean
	public FilterRegistrationBean<CustomSiteMeshFilter> siteMeshFilter() {
		FilterRegistrationBean<CustomSiteMeshFilter> registration = new FilterRegistrationBean<>();
		registration.setFilter(new CustomSiteMeshFilter());
		registration.addUrlPatterns("/*");
		return registration;
	}
}
