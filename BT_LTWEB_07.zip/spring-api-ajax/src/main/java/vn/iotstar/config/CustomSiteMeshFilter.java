package vn.iotstar.config;

import org.sitemesh.builder.SiteMeshFilterBuilder;
import org.sitemesh.config.ConfigurableSiteMeshFilter;

public class CustomSiteMeshFilter extends ConfigurableSiteMeshFilter {
	@Override
	protected void applyCustomConfiguration(SiteMeshFilterBuilder builder) {
		// decorator mặc định
		builder.addDecoratorPath("/*", "/decorators/web.jsp")
				// decorator riêng cho /admin/*
				.addDecoratorPath("/admin/*", "/decorators/admin.jsp")
				// các đường dẫn KHÔNG bọc layout
				.addExcludedPath("/login*").addExcludedPath("/login/*")
				.addExcludedPath("/alogin*").addExcludedPath("/alogin/*")
				.addExcludedPath("/api/*")
				.addExcludedPath("/images/*")
				.addExcludedPath("/swagger-ui*").addExcludedPath("/swagger-ui/*")
				.addExcludedPath("/v3/api-docs*").addExcludedPath("/v3/api-docs/*");
	}
}
