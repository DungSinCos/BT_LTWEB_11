<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ include file="/common/taglib.jsp"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>var contextPath = "${pageContext.request.contextPath}"</script>
<title><sitemesh:write property='title'/></title>
<sitemesh:write property='head'/>
</head>
<body>
	<nav class="navbar navbar-expand navbar-dark bg-dark">
		<div class="container">
			<span class="navbar-brand">Admin</span>
			<ul class="navbar-nav me-auto">
				<li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/admin/ajax/category">Category</a></li>
				<li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/admin/ajax/product">Product</a></li>
				<li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/swagger-ui/index.html" target="_blank">Swagger</a></li>
			</ul>
		</div>
	</nav>
	<main class="container my-4">
		<sitemesh:write property='body'/>
	</main>
	<footer class="container text-center text-muted my-4">Spring Boot API + Ajax</footer>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
