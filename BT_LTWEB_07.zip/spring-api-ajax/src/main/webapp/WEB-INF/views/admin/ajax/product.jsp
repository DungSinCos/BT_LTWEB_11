<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<title>Quản lý Product (Ajax)</title>
</head>
<body>
<h3>Quản lý Product (Ajax)</h3>
<p><button class="btn btn-success" id="btnAdd"><i class="fas fa-plus"></i> Thêm Product</button></p>

<table class="table table-striped" id="productTable">
  <thead>
    <tr><th>Id</th><th>Ảnh</th><th>Tên</th><th>Giá</th><th>Giảm giá</th>
        <th>SL</th><th>Category</th><th>Trạng thái</th><th>Actions</th></tr>
  </thead>
  <tbody></tbody>
</table>

<div class="modal" tabindex="-1" id="productModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="productForm" enctype="multipart/form-data">
        <div class="modal-header">
          <h5 class="modal-title" id="productModalTitle">Product</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="productId" id="productId">
          <div class="mb-2"><label class="form-label">Tên</label>
            <input class="form-control" name="productName" id="productName" required></div>
          <div class="mb-2"><label class="form-label">Giá</label>
            <input type="number" step="0.01" min="0" class="form-control" name="unitPrice" id="unitPrice" required></div>
          <div class="mb-2"><label class="form-label">Giảm giá</label>
            <input type="number" step="0.01" min="0" class="form-control" name="discount" id="discount" value="0" required></div>
          <div class="mb-2"><label class="form-label">Số lượng</label>
            <input type="number" min="0" class="form-control" name="quantity" id="quantity" required></div>
          <div class="mb-2"><label class="form-label">Mô tả</label>
            <textarea class="form-control" name="description" id="description" required></textarea></div>
          <div class="mb-2"><label class="form-label">Category</label>
            <select class="form-select" name="categoryId" id="categoryId"></select></div>
          <div class="mb-2"><label class="form-label">Trạng thái</label>
            <select class="form-select" name="status" id="status">
              <option value="1">Đang bán</option><option value="0">Ngừng bán</option>
            </select></div>
          <div class="mb-2"><label class="form-label">Ảnh</label>
            <input type="file" class="form-control" name="imageFile" id="imageFile" accept="image/*"></div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
          <button type="submit" class="btn btn-primary">Lưu</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
$(function () {
  var modal = new bootstrap.Modal(document.getElementById('productModal'));

  function loadCategories() {
    $.getJSON(contextPath + '/api/category', function (res) {
      var sel = $('#categoryId').empty();
      $.each(res.body, function (i, c) {
        sel.append($('<option>').val(c.categoryId).text(c.categoryName));
      });
    });
  }

  function loadProducts() {
    $.getJSON(contextPath + '/api/product', function (res) {
      var tbody = $('#productTable tbody').empty();
      $.each(res.body, function (i, p) {
        var tr = $('<tr>').data('product', p);
        tr.append($('<td>').text(p.productId));
        var td = $('<td>');
        if (p.images) td.append($('<img>').attr('src', contextPath + '/images/' + p.images).css('width', '70px'));
        tr.append(td);
        tr.append($('<td>').text(p.productName));
        tr.append($('<td>').text(p.unitPrice));
        tr.append($('<td>').text(p.discount));
        tr.append($('<td>').text(p.quantity));
        tr.append($('<td>').text(p.category ? p.category.categoryName : ''));
        tr.append($('<td>').text(p.status == 1 ? 'Đang bán' : 'Ngừng bán'));
        tr.append($('<td>')
          .append($('<button>').addClass('btn btn-outline-warning btn-edit me-1').html('<i class="fa fa-edit"></i>'))
          .append($('<button>').addClass('btn btn-outline-danger btn-delete').html('<i class="fa fa-trash"></i>')));
        tbody.append(tr);
      });
    });
  }

  $('#btnAdd').click(function () {
    $('#productForm')[0].reset();
    $('#productId').val('');
    $('#productModalTitle').text('Thêm Product');
    modal.show();
  });

  $('#productTable').on('click', '.btn-edit', function () {
    var p = $(this).closest('tr').data('product');
    $('#productForm')[0].reset();
    $('#productId').val(p.productId);
    $('#productName').val(p.productName);
    $('#unitPrice').val(p.unitPrice);
    $('#discount').val(p.discount);
    $('#quantity').val(p.quantity);
    $('#description').val(p.description);
    $('#status').val(p.status);
    if (p.category) $('#categoryId').val(p.category.categoryId);
    $('#productModalTitle').text('Sửa Product');
    modal.show();
  });

  $('#productForm').submit(function (e) {
    e.preventDefault();
    var isEdit = $('#productId').val() !== '';
    $.ajax({
      url: contextPath + '/api/product/' + (isEdit ? 'updateProduct' : 'addProduct'),
      type: isEdit ? 'PUT' : 'POST',
      data: new FormData(this),
      processData: false,
      contentType: false,
      dataType: 'json',
      success: function () { modal.hide(); loadProducts(); },
      error: function (xhr) {
        alert(xhr.responseJSON ? xhr.responseJSON.message : 'Có lỗi xảy ra');
      }
    });
  });

  $('#productTable').on('click', '.btn-delete', function () {
    var p = $(this).closest('tr').data('product');
    if (!confirm('Bạn có chắc muốn xóa sản phẩm này?')) return;
    $.ajax({
      url: contextPath + '/api/product/deleteProduct?productId=' + p.productId,
      type: 'DELETE',
      dataType: 'json',
      success: loadProducts,
      error: function (xhr) {
        alert(xhr.responseJSON ? xhr.responseJSON.message : 'Không xóa được');
      }
    });
  });

  loadCategories();
  loadProducts();
});
</script>
</body>
</html>
