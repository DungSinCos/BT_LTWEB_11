<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<title>Quản lý Category (Ajax)</title>
</head>
<body>
<h3>Quản lý Category (Ajax)</h3>
<p><button class="btn btn-success" id="btnAdd"><i class="fas fa-plus"></i> Thêm Category</button></p>

<table class="table table-striped" id="categoryTable">
  <thead><tr><th>Id</th><th>Icon</th><th>Name</th><th>Actions</th></tr></thead>
  <tbody></tbody>
</table>

<div class="modal" tabindex="-1" id="categoryModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="categoryForm" enctype="multipart/form-data">
        <div class="modal-header">
          <h5 class="modal-title" id="categoryModalTitle">Category</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="categoryId" id="categoryId">
          <div class="mb-3">
            <label class="form-label">Category Name</label>
            <input type="text" class="form-control" name="categoryName" id="categoryName" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Icon</label>
            <input type="file" class="form-control" name="icon" id="icon" accept="image/*">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
          <button type="submit" class="btn btn-primary">Lưu</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
$(function () {
  var modal = new bootstrap.Modal(document.getElementById('categoryModal'));

  function loadCategories() {
    $.getJSON(contextPath + '/api/category', function (res) {
      var tbody = $('#categoryTable tbody').empty();
      $.each(res.body, function (i, c) {
        var tr = $('<tr>');
        tr.append($('<td>').text(c.categoryId));
        var td = $('<td>');
        if (c.icon) td.append($('<img>').attr('src', contextPath + '/images/' + c.icon).css('width', '70px'));
        tr.append(td);
        tr.append($('<td>').text(c.categoryName));
        tr.append($('<td>')
          .append($('<button>').addClass('btn btn-outline-warning btn-edit me-1')
                  .data('id', c.categoryId).data('name', c.categoryName)
                  .html('<i class="fa fa-edit"></i>'))
          .append($('<button>').addClass('btn btn-outline-danger btn-delete')
                  .data('id', c.categoryId)
                  .html('<i class="fa fa-trash"></i>')));
        tbody.append(tr);
      });
    });
  }

  $('#btnAdd').click(function () {
    $('#categoryForm')[0].reset();
    $('#categoryId').val('');
    $('#categoryModalTitle').text('Thêm Category');
    modal.show();
  });

  $('#categoryTable').on('click', '.btn-edit', function () {
    $('#categoryForm')[0].reset();
    $('#categoryId').val($(this).data('id'));
    $('#categoryName').val($(this).data('name'));
    $('#categoryModalTitle').text('Sửa Category');
    modal.show();
  });

  $('#categoryForm').submit(function (e) {
    e.preventDefault();
    var isEdit = $('#categoryId').val() !== '';
    $.ajax({
      url: contextPath + '/api/category/' + (isEdit ? 'updateCategory' : 'addCategory'),
      type: isEdit ? 'PUT' : 'POST',
      data: new FormData(this),
      processData: false,
      contentType: false,
      dataType: 'json',
      success: function () { modal.hide(); loadCategories(); },
      error: function (xhr) {
        alert(xhr.responseJSON ? xhr.responseJSON.message : 'Có lỗi xảy ra');
      }
    });
  });

  $('#categoryTable').on('click', '.btn-delete', function () {
    var id = $(this).data('id');
    if (!confirm('Bạn có chắc muốn xóa category này?')) return;
    $.ajax({
      url: contextPath + '/api/category/deleteCategory?categoryId=' + id,
      type: 'DELETE',
      dataType: 'json',
      success: loadCategories,
      error: function (xhr) {
        alert(xhr.responseJSON ? xhr.responseJSON.message : 'Không xóa được');
      }
    });
  });

  loadCategories();
});
</script>
</body>
</html>
