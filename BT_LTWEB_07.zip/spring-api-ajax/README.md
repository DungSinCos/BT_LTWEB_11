# spring-api-ajax

Spring Boot 3.1.5 + JSP + SiteMesh 3 + Swagger 3 (springdoc) + Ajax (jQuery)

## Chạy bằng Spring Tool Suite
1. Tạo database `ltweb_api` trong SQL Server, sửa user/password trong `src/main/resources/application.properties`.
2. File > Import > Maven > Existing Maven Projects > chọn thư mục `spring-api-ajax`.
3. Chuột phải project > Run As > Spring Boot App (class `SpringbootApiApplication`).

## Đường dẫn
- Category (Ajax): http://localhost:8082/admin/ajax/category
- Product  (Ajax): http://localhost:8082/admin/ajax/product
- Swagger 3:       http://localhost:8082/swagger-ui/index.html
- API Category:    /api/category, /api/category/{getCategory|addCategory|updateCategory|deleteCategory}
- API Product:     /api/product,  /api/product/{getProduct|addProduct|updateProduct|deleteProduct}
- Ảnh upload lưu trong thư mục `uploads/`, xem qua /images/{tên-file}

Lưu ý: Category chỉ xóa được khi không còn Product thuộc nó. Hãy thêm Category trước khi thêm Product.
