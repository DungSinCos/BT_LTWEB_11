# IOTSTAR SHOP – Spring Boot 4.1.1 + Spring Security 7

Register (OTP mail) · Login bằng **username hoặc email** · Forgot password (OTP mail) · CRUD User / Product ·
Tìm kiếm + phân trang · Đếm User / Product · Upload ảnh Cloudinary · MapStruct · Thymeleaf · SQL Server.

## Chạy trong Spring Tool Suite (STS)
1. **File → Import → Maven → Existing Maven Projects** → chọn thư mục `shop-springboot-4-1-1`.
2. Cần **JDK 26** (hoặc sửa `<java.version>` trong `pom.xml` cho khớp JDK của bạn, vd 21).
3. Mở SQL Server, tạo database: `CREATE DATABASE shopdb;`
4. Sửa file **`.env`** (cùng cấp `pom.xml`): `DB_PASSWORD`, SMTP, Cloudinary.
   - Chưa có SMTP? Giữ `OTP_DEBUG=true` → mã OTP được in ra **Console** của STS.
   - Chưa có Cloudinary? Vẫn chạy được, chỉ upload ảnh sẽ báo lỗi cấu hình.
5. Chuột phải project → **Run As → Spring Boot App** → mở http://localhost:8080

Bảng và dữ liệu mẫu (`ROLE_USER`, `ROLE_ADMIN`, tài khoản admin) được tạo tự động – **không cần chạy SQL thêm**.

## Tài khoản mặc định
| Username | Email | Mật khẩu | Role |
|---|---|---|---|
| `admin` | `admin@shop.local` | `123456` | ROLE_ADMIN |

(Đổi qua `ADMIN_USERNAME`, `ADMIN_EMAIL`, `ADMIN_PASSWORD` trong `.env`.)

## Chức năng
- **Đăng ký**: tạo tài khoản (chưa kích hoạt) → gửi OTP 6 số qua mail → xác nhận → đăng nhập; có *Gửi lại OTP*.
- **Đăng nhập**: nhập username *hoặc* email; session; header hiển thị avatar, họ tên, username, role.
- **Quên mật khẩu**: nhập email → OTP → đặt mật khẩu mới.
- **User** (chỉ ADMIN): CRUD, tìm kiếm, phân trang, upload avatar, đếm số product của từng user, không tự xóa chính mình.
- **Product**: CRUD, tìm kiếm, phân trang, upload ảnh Cloudinary; chỉ chủ sở hữu hoặc ADMIN được sửa/xóa.
- **Dashboard**: tổng User, tổng Product, số product của tôi.

## Cấu trúc
```
vn.iotstar
 ├─ config      SecurityConfig, CloudinaryConfig, DataInitializer
 ├─ controller  Auth / Home / User / Product + GlobalExceptionHandler
 ├─ dto         UserDTO, ProductDTO, RegisterDTO, VerifyOtpDTO, ForgotPasswordDTO, ResetPasswordDTO
 ├─ entity      User, Role, Product, OtpToken
 ├─ mapper      UserMapper, ProductMapper (MapStruct)
 ├─ repository  Spring Data JPA
 ├─ security    CustomUserDetails, CustomUserDetailsService
 └─ service     (+ impl) Auth, Otp, Email, Cloudinary, User, Product
```

## Lưu ý bảo mật
- `.env` đã nằm trong `.gitignore` – **không đẩy lên GitHub**.
- OTP lưu dạng hash BCrypt, hết hạn sau 5 phút, tối đa 5 lần thử.
- Nếu bạn từng dán App Password Gmail / API secret Cloudinary vào tài liệu hay repo công khai, hãy **tạo lại khóa mới**.
