package vn.iotstar.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import vn.iotstar.dto.ProductDTO;
import vn.iotstar.security.CustomUserDetails;
import vn.iotstar.service.ProductService;

@Controller
@RequestMapping("/products")
@RequiredArgsConstructor
public class ProductController {

	private final ProductService productService;

	/** Chi chu so huu hoac ADMIN moi duoc sua/xoa */
	private ProductDTO loadAndCheckOwner(Long id, CustomUserDetails me) {
		ProductDTO existing = productService.findById(id);
		if (!me.isAdmin() && !me.getId().equals(existing.getUserId()))
			throw new AccessDeniedException("Bạn không có quyền với sản phẩm này");
		return existing;
	}

	@GetMapping
	public String list(@RequestParam(defaultValue = "") String keyword, @RequestParam(defaultValue = "0") int page,
			@RequestParam(defaultValue = "10") int size, Model model) {
		model.addAttribute("products", productService.findAll(keyword, page, size));
		model.addAttribute("keyword", keyword);
		model.addAttribute("size", size);
		return "products/list";
	}

	@GetMapping("/create")
	public String create(Model model) {
		model.addAttribute("productDTO", new ProductDTO());
		model.addAttribute("mode", "create");
		return "products/form";
	}

	@PostMapping("/create")
	public String create(@Valid @ModelAttribute ProductDTO dto, BindingResult result,
			@AuthenticationPrincipal CustomUserDetails me, Model model, RedirectAttributes redirect) {
		model.addAttribute("mode", "create");
		if (result.hasErrors())
			return "products/form";
		dto.setUserId(me.getId());
		try {
			productService.create(dto);
		} catch (IllegalArgumentException e) {
			result.reject("product.error", e.getMessage());
			return "products/form";
		}
		redirect.addFlashAttribute("success", "Tạo sản phẩm thành công.");
		return "redirect:/products";
	}

	@GetMapping("/edit/{id}")
	public String edit(@PathVariable Long id, @AuthenticationPrincipal CustomUserDetails me, Model model) {
		model.addAttribute("productDTO", loadAndCheckOwner(id, me));
		model.addAttribute("mode", "edit");
		return "products/form";
	}

	@PostMapping("/edit/{id}")
	public String edit(@PathVariable Long id, @Valid @ModelAttribute ProductDTO dto, BindingResult result,
			@AuthenticationPrincipal CustomUserDetails me, Model model, RedirectAttributes redirect) {
		ProductDTO existing = loadAndCheckOwner(id, me);
		dto.setId(id);
		dto.setImageUrl(existing.getImageUrl());
		model.addAttribute("mode", "edit");
		if (result.hasErrors())
			return "products/form";
		try {
			productService.update(id, dto);
		} catch (IllegalArgumentException e) {
			result.reject("product.error", e.getMessage());
			return "products/form";
		}
		redirect.addFlashAttribute("success", "Cập nhật sản phẩm thành công.");
		return "redirect:/products";
	}

	@PostMapping("/delete/{id}")
	public String delete(@PathVariable Long id, @AuthenticationPrincipal CustomUserDetails me,
			RedirectAttributes redirect) {
		loadAndCheckOwner(id, me);
		productService.delete(id);
		redirect.addFlashAttribute("success", "Xóa sản phẩm thành công.");
		return "redirect:/products";
	}
}
