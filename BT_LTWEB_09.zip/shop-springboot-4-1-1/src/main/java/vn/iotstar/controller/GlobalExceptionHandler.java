package vn.iotstar.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler({ IllegalArgumentException.class, IllegalStateException.class })
	public ModelAndView handle(RuntimeException ex) {
		ModelAndView mv = new ModelAndView("error");
		mv.addObject("message", ex.getMessage());
		return mv;
	}
}
