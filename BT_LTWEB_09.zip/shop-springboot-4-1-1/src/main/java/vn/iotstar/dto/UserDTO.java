package vn.iotstar.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;

@Data
public class UserDTO {

	private Long id;

	@NotBlank(message = "Username không được để trống")
	@Pattern(regexp = "^[A-Za-z0-9._-]{3,50}$", message = "Username 3-50 ký tự (chữ, số, . _ -)")
	private String username;

	@NotBlank(message = "Email không được để trống")
	@Email(message = "Email không hợp lệ")
	private String email;

	@NotBlank(message = "Họ tên không được để trống")
	private String fullName;

	/** Chỉ dùng khi Admin tạo user; bỏ trống = 123456 */
	private String password;

	private String roleName;
	private boolean enabled;

	/** URL ảnh đại diện */
	private String images;
	private MultipartFile avatar;

	private long productCount;
	private LocalDateTime createdAt;
}
