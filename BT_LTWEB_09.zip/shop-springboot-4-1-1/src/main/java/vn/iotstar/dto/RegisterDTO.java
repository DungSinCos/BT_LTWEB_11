package vn.iotstar.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class RegisterDTO {

	@NotBlank(message = "Username không được để trống")
	@Pattern(regexp = "^[A-Za-z0-9._-]{3,50}$", message = "Username 3-50 ký tự (chữ, số, . _ -)")
	private String username;

	@NotBlank(message = "Email không được để trống")
	@Email(message = "Email không hợp lệ")
	private String email;

	@NotBlank(message = "Họ tên không được để trống")
	private String fullName;

	@NotBlank(message = "Mật khẩu không được để trống")
	@Size(min = 6, max = 60, message = "Mật khẩu từ 6 đến 60 ký tự")
	private String password;

	@NotBlank(message = "Vui lòng xác nhận mật khẩu")
	private String confirmPassword;
}
