package vn.iotstar.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class ResetPasswordDTO {

	@NotBlank(message = "Email không được để trống")
	@Email(message = "Email không hợp lệ")
	private String email;

	@NotBlank(message = "Vui lòng nhập OTP")
	@Size(min = 6, max = 6, message = "OTP gồm 6 số")
	private String otp;

	@NotBlank(message = "Mật khẩu mới không được để trống")
	@Size(min = 6, max = 60, message = "Mật khẩu từ 6 đến 60 ký tự")
	private String password;

	@NotBlank(message = "Vui lòng xác nhận mật khẩu")
	private String confirmPassword;
}
