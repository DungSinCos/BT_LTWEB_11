package vn.iotstar.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import vn.iotstar.dto.RegisterDTO;
import vn.iotstar.entity.Role;
import vn.iotstar.entity.User;
import vn.iotstar.repository.RoleRepository;
import vn.iotstar.repository.UserRepository;
import vn.iotstar.service.AuthService;
import vn.iotstar.service.OtpService;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

	private final UserRepository userRepository;
	private final RoleRepository roleRepository;
	private final PasswordEncoder passwordEncoder;
	private final OtpService otpService;

	@Override
	@Transactional
	public void register(RegisterDTO dto) {
		String email = dto.getEmail().trim().toLowerCase();
		String username = dto.getUsername().trim();

		if (!dto.getPassword().equals(dto.getConfirmPassword()))
			throw new IllegalArgumentException("Mật khẩu xác nhận không đúng");

		// Tai khoan dang ky truoc do nhung chua xac thuc OTP -> cho dang ky lai
		userRepository.findByEmail(email).ifPresent(existing -> {
			if (existing.isEnabled())
				throw new IllegalArgumentException("Email đã tồn tại");
			userRepository.delete(existing);
			userRepository.flush();
		});
		if (userRepository.existsByUsername(username))
			throw new IllegalArgumentException("Username đã tồn tại");

		Role role = roleRepository.findByName("ROLE_USER")
				.orElseThrow(() -> new IllegalStateException("Chưa có ROLE_USER trong database"));

		userRepository.save(User.builder()
				.username(username)
				.email(email)
				.password(passwordEncoder.encode(dto.getPassword()))
				.fullName(dto.getFullName().trim())
				.enabled(false)
				.role(role)
				.build());
		otpService.sendRegisterOtp(email);
	}

	@Override
	@Transactional
	public boolean verifyRegister(String email, String otp) {
		email = email.trim().toLowerCase();
		if (!otpService.verifyRegisterOtp(email, otp))
			return false;
		User user = userRepository.findByEmail(email)
				.orElseThrow(() -> new IllegalArgumentException("User không tồn tại"));
		user.setEnabled(true);
		return true;
	}

	@Override
	@Transactional
	public void resendRegisterOtp(String email) {
		email = email.trim().toLowerCase();
		User user = userRepository.findByEmail(email)
				.orElseThrow(() -> new IllegalArgumentException("Email chưa đăng ký"));
		if (user.isEnabled())
			throw new IllegalArgumentException("Tài khoản đã được xác thực, hãy đăng nhập");
		otpService.sendRegisterOtp(email);
	}

	/** Khong tiet lo email co ton tai hay khong. */
	@Override
	@Transactional
	public void forgotPassword(String email) {
		String e = email.trim().toLowerCase();
		if (userRepository.existsByEmail(e))
			otpService.sendResetPasswordOtp(e);
	}

	@Override
	@Transactional
	public void resetPassword(String email, String otp, String newPassword) {
		String e = email.trim().toLowerCase();
		if (!otpService.verifyResetPasswordOtp(e, otp))
			throw new IllegalArgumentException("OTP không hợp lệ, đã hết hạn hoặc quá số lần thử");
		User user = userRepository.findByEmail(e)
				.orElseThrow(() -> new IllegalArgumentException("Email không tồn tại"));
		user.setPassword(passwordEncoder.encode(newPassword));
	}
}
