package vn.iotstar.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import vn.iotstar.dto.UserDTO;
import vn.iotstar.entity.Product;
import vn.iotstar.entity.Role;
import vn.iotstar.entity.User;
import vn.iotstar.mapper.UserMapper;
import vn.iotstar.repository.ProductRepository;
import vn.iotstar.repository.RoleRepository;
import vn.iotstar.repository.UserRepository;
import vn.iotstar.service.CloudinaryService;
import vn.iotstar.service.CloudinaryUploadResult;
import vn.iotstar.service.UserService;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

	private static final String DEFAULT_PASSWORD = "123456";

	private final UserRepository userRepository;
	private final RoleRepository roleRepository;
	private final ProductRepository productRepository;
	private final UserMapper mapper;
	private final PasswordEncoder passwordEncoder;
	private final CloudinaryService cloudinaryService;

	private UserDTO toDtoWithCount(User user) {
		UserDTO dto = mapper.toDTO(user);
		dto.setProductCount(productRepository.countByUserId(user.getId()));
		return dto;
	}

	private Role findRole(String roleName) {
		String name = (roleName == null || roleName.isBlank()) ? "ROLE_USER" : roleName;
		return roleRepository.findByName(name).orElseThrow(() -> new IllegalArgumentException("Role không tồn tại"));
	}

	@Override
	@Transactional(readOnly = true)
	public Page<UserDTO> findAll(String keyword, int page, int size) {
		Pageable pageable = PageRequest.of(Math.max(page, 0), Math.max(size, 1), Sort.by(Sort.Direction.DESC, "id"));
		return userRepository.search(keyword == null ? "" : keyword.trim(), pageable).map(this::toDtoWithCount);
	}

	@Override
	@Transactional(readOnly = true)
	public UserDTO findById(Long id) {
		return toDtoWithCount(userRepository.findById(id)
				.orElseThrow(() -> new IllegalArgumentException("User không tồn tại")));
	}

	@Override
	@Transactional
	public UserDTO create(UserDTO dto) {
		String username = dto.getUsername().trim();
		String email = dto.getEmail().trim().toLowerCase();
		if (userRepository.existsByUsername(username))
			throw new IllegalArgumentException("Username đã tồn tại");
		if (userRepository.existsByEmail(email))
			throw new IllegalArgumentException("Email đã tồn tại");

		String rawPassword = (dto.getPassword() == null || dto.getPassword().isBlank()) ? DEFAULT_PASSWORD
				: dto.getPassword();
		if (rawPassword.length() < 6)
			throw new IllegalArgumentException("Mật khẩu tối thiểu 6 ký tự");

		User user = mapper.toEntity(dto);
		user.setUsername(username);
		user.setEmail(email);
		user.setPassword(passwordEncoder.encode(rawPassword));
		user.setRole(findRole(dto.getRoleName()));
		user.setEnabled(dto.isEnabled());
		user.setImages(null);

		if (dto.getAvatar() != null && !dto.getAvatar().isEmpty()) {
			CloudinaryUploadResult r = cloudinaryService.upload(dto.getAvatar(), "shop/avatars");
			user.setImages(r.url());
			user.setImagePublicId(r.publicId());
		}
		return toDtoWithCount(userRepository.save(user));
	}

	@Override
	@Transactional
	public UserDTO update(Long id, UserDTO dto) {
		User user = userRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("User không tồn tại"));
		String username = dto.getUsername().trim();
		String email = dto.getEmail().trim().toLowerCase();

		if (!user.getUsername().equalsIgnoreCase(username) && userRepository.existsByUsername(username))
			throw new IllegalArgumentException("Username đã tồn tại");
		if (!user.getEmail().equalsIgnoreCase(email) && userRepository.existsByEmail(email))
			throw new IllegalArgumentException("Email đã tồn tại");

		user.setUsername(username);
		user.setEmail(email);
		user.setFullName(dto.getFullName().trim());
		user.setEnabled(dto.isEnabled());
		if (dto.getRoleName() != null && !dto.getRoleName().isBlank())
			user.setRole(findRole(dto.getRoleName()));

		if (dto.getAvatar() != null && !dto.getAvatar().isEmpty()) {
			CloudinaryUploadResult r = cloudinaryService.upload(dto.getAvatar(), "shop/avatars");
			cloudinaryService.delete(user.getImagePublicId());
			user.setImages(r.url());
			user.setImagePublicId(r.publicId());
		}
		return toDtoWithCount(userRepository.save(user));
	}

	@Override
	@Transactional
	public void delete(Long id, Long currentUserId) {
		if (id.equals(currentUserId))
			throw new IllegalArgumentException("Không thể tự xóa tài khoản đang đăng nhập");
		User user = userRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("User không tồn tại"));
		// Xoa anh tren Cloudinary (san pham se bi xoa theo cascade)
		for (Product p : user.getProducts())
			cloudinaryService.delete(p.getImagePublicId());
		cloudinaryService.delete(user.getImagePublicId());
		userRepository.delete(user);
	}

	@Override
	@Transactional(readOnly = true)
	public long countUsers() {
		return userRepository.count();
	}

	@Override
	@Transactional(readOnly = true)
	public long countProducts(Long userId) {
		return productRepository.countByUserId(userId);
	}
}
