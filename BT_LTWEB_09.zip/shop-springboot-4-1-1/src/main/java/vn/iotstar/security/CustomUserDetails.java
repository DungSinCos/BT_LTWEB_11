package vn.iotstar.security;

import lombok.Getter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import vn.iotstar.entity.User;

import java.util.Collection;
import java.util.List;

/**
 * Principal tuy chinh: view lay duoc fullName, images, email, role qua
 * ${#authentication.principal.xxx}
 */
@Getter
public class CustomUserDetails implements UserDetails {

	private static final long serialVersionUID = 1L;

	private final Long id;
	private final String username;
	private final String email;
	private final String password;
	private final String fullName;
	private final String images;
	private final String role;
	private final boolean enabled;

	public CustomUserDetails(User user) {
		this.id = user.getId();
		this.username = user.getUsername();
		this.email = user.getEmail();
		this.password = user.getPassword();
		this.fullName = user.getFullName();
		this.images = user.getImages();
		this.role = user.getRole().getName();
		this.enabled = user.isEnabled();
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return List.of(new SimpleGrantedAuthority(role)); // ROLE_USER / ROLE_ADMIN
	}

	public boolean isAdmin() {
		return "ROLE_ADMIN".equals(role);
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}
}
