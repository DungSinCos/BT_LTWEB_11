package vn.iotstar.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;
import vn.iotstar.entity.Role;
import vn.iotstar.entity.User;
import vn.iotstar.repository.RoleRepository;
import vn.iotstar.repository.UserRepository;

/** Tao san ROLE_USER, ROLE_ADMIN va 1 tai khoan admin (lan chay dau tien). */
@Configuration
public class DataInitializer {

	@Bean
	CommandLineRunner initData(RoleRepository roles, UserRepository users, PasswordEncoder encoder,
			@Value("${app.admin.username}") String adminUsername,
			@Value("${app.admin.email}") String adminEmail,
			@Value("${app.admin.password}") String adminPassword) {
		return args -> {
			roles.findByName("ROLE_USER").orElseGet(() -> roles.save(Role.builder().name("ROLE_USER").build()));
			Role adminRole = roles.findByName("ROLE_ADMIN")
					.orElseGet(() -> roles.save(Role.builder().name("ROLE_ADMIN").build()));

			if (!users.existsByUsername(adminUsername) && !users.existsByEmail(adminEmail)) {
				users.save(User.builder()
						.username(adminUsername)
						.email(adminEmail.toLowerCase())
						.password(encoder.encode(adminPassword))
						.fullName("System Administrator")
						.enabled(true)
						.role(adminRole)
						.build());
			}
		};
	}
}
